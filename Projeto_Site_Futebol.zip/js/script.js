
// Efeito interativo simples ao clicar no título
document.addEventListener("DOMContentLoaded", function () {
    document.querySelector("h1").addEventListener("click", function () {
        alert("Bem-vindo ao Futebol ao Vivo!");
    });
});
